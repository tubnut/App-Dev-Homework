import pygame
from pygame.locals import *

class Obstacle(pygame.sprite.Sprite):

    pass
    # def __init__(self, *groups: _Group) -> None:
    #     super().__init__(*groups)