import pygame, sys
from pygame.locals import *
from Card import *
from Deck import *
#checks if player starts with 10 and an Ace
def startsWithTen(hand):
    for c in hand:
        if c.value == 10 and c.rank == "Ace"  :
            return True
        else:
            return False
        
#Changes ace value to 11 by default
def aceMoment():
    for c in playerCards:
        if c.rank == "Ace"  :
            c.aceChange()
    for i in dealerCards:
        if i.rank == "Ace"  :
            i.aceChange()

#Deals cards to both players
def dealCards():
    for _ in range(2):
        dealerCards.append(deck.draw())
    for _ in range(2):
        playerCards.append(deck.draw())

#Counts points 
def countPoints():
    playerScoreText = font.render(f'Score: {sum([card.value for card in playerCards])}', True, (255,255,255))
    playerRect = playerScoreText.get_rect()
    playerRect.center = (75,575)
    my_display.blit(playerScoreText, playerRect)

    dealerScoreText = font.render(f'Score: {sum([card.value for card in dealerCards if card.up] )}', True, (255,255,255))
    dealerRect = dealerScoreText.get_rect()
    my_display.blit(dealerScoreText, dealerRect)


#Prints cards to the screen and offsets their x value by 150
def displayCards():
    x = 100
    x2 = 100
    for card in dealerCards:
        card.display(my_display, x, 50)
        x += 150
    for card in playerCards:
        card.display(my_display, x2, 350)
        x2 += 150
    dealerCards[1].flipDown()

def declareWinner(winner):
    winnerText = font.render(f'{winner} Wins!', True, (255,255,255))
    winnerRect = winnerText.get_rect()
    winnerRect.center = (400,300)
    my_display.blit(winnerText, winnerRect)

#Declaring hands and deck
playerCards = []
dealerCards = []

deck = Deck()

pygame.init()
my_display = pygame.display.set_mode((800,600))
clock = pygame.time.Clock()
pygame.display.set_caption('Please help me')

font = pygame.font.Font('freesansbold.ttf', 32)

dealCards()

playerTurn = True
winner = "None"
displayWinner = False

#Game Loop
end = True
while end:

    pygame.display.update()
    clock.tick(30)
    my_display.fill((0,0,0))

    if startsWithTen(playerCards):
        declareWinner("Player")
    
    if startsWithTen(dealerCards):
        declareWinner("Dealer")


    displayCards()
    countPoints()

    for event in pygame.event.get():
        if event.type == pygame.QUIT or (event.type==KEYDOWN and event.key==K_ESCAPE):
            end = False
            pygame.quit()
        #Checks if space is pressed and if it is it draws a card
        if event.type == KEYDOWN:
            if event.key == K_SPACE and playerTurn == True:
                #Draws a card until player is done
                playerCards.append(deck.draw())
                #Checks if you would go over 21 with next draw
                if sum([card.value for card in playerCards]) > 21:
                    winner = "Dealer"
                    displayWinner = True
            if event.key == K_t:
                while sum([card.value for card in dealerCards]) < 17:
                    dealerCards.append(deck.draw())
                if sum([card.value for card in dealerCards]) > 21:
                    winner = "Player"
                    displayWinner = True
    if displayWinner == True:
        declareWinner(winner)