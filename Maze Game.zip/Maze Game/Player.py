import pygame as pg
from pygame.locals import *

class Player():
    def __init__(self, x_pos = 0, y_pos = 10, width = 50, height = 50):
        self.x_pos = x_pos
        self.y_pos = y_pos
        self.width = width
        self.height = height
        self.img = pg.image.load('Resources/goofyAhhCat.png')
    
    def move_left(self):
        self.x_pos -= 10
    
    def move_right(self):
        self.x_pos += 10
    
    def move_up(self):
        self.y_pos -= 10

    def move_down(self):
        self.y_pos += 10

    def draw(self, window):
       window.blit(self.img,(self.x_pos,self.y_pos))

    def get_rect(self):
        my_rect = self.img.get_rect()
        return (self.x_pos,self.y_pos,my_rect[2],my_rect[3])
    