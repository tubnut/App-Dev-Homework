import pygame as pg
from pygame.locals import *

class Wall():
    def __init__(self, x_pos=10, y_pos=10, length = 50, width = 50):
        self.x_pos = x_pos
        self.y_pos = y_pos
        self.length = length
        self.width = width
        self.img = pg.image.load('Resources/wall.png')

    
    def __str__(self):
        return f"Position = ({self.x_pos}, {self.y_pos}), Height = {self.height}, Weight = {self.weight}, Color = {self.color}"

    def draw(self, window):
       window.blit(self.img,(self.x_pos,self.y_pos))
    