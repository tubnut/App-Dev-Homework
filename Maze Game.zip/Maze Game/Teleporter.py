import pygame as pg
from pygame.locals import *

class Teleporter():
    def __init__(self, x_pos=10, y_pos=10, length = 50, width = 50):
        self.x_pos = x_pos
        self.y_pos = y_pos
        self.length = length
        self.width = width
        #self.img = pg.image.load('Resources/Smiley.jpg')
    
    def __str__(self):
        return f"Position = ({self.x_pos}, {self.y_pos}), Height = {self.height}, Weight = {self.weight}, Color = {self.color}"

    def draw(self, window):
        window.blit(self.img,(self.x_pos,self.y_pos))

    # def get_rect(self):
    #     my_rect = self.img.get_rect()
    #     return (self.x_pos,self.y_pos,my_rect[2],my_rect[3])

    